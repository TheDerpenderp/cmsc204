
public class InvalidNotationFormatException extends Exception{
	
	public InvalidNotationFormatException() {
		super();
	}

	
}
