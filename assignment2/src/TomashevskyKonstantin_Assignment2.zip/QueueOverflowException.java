
public class QueueOverflowException extends Exception {

	public QueueOverflowException() {
		super();
	}
}
