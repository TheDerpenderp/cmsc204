
public class StackOverflowException extends Exception {

	public StackOverflowException() {
		super();
	}

}
