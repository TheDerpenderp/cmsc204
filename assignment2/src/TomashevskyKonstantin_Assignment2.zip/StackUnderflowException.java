
public class StackUnderflowException extends Exception {

	public StackUnderflowException() {
		super();
	}
}
